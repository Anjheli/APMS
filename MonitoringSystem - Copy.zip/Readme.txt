*yung password ng student ay parent contact number
*lalabas lang ung link sa baba ng Table pag mababa ung performance sa subject na yon.
*pag nag add ng subject kasama na din don ung link ng lesson plan yun yung ilalabas na link pag alanganin grade nila sa subject na yon.
*pag nag add kayo ng subject sabay nyo na yung link ng lesson plan ng subeject nayon


*ok na yung responsive sa student pag mobile gamit.




