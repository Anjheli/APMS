-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2023 at 04:26 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monitoringsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `abm_manga_11_pe1_1_5`
--

CREATE TABLE `abm_manga_11_pe1_1_5` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `abm_manga_11_pe1_1_5`
--

INSERT INTO `abm_manga_11_pe1_1_5` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `abm_manga_11_pe1_1_205`
--

CREATE TABLE `abm_manga_11_pe1_1_205` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `abm_manga_11_pe1_1_205`
--

INSERT INTO `abm_manga_11_pe1_1_205` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ga_manga_11_pe1_1_2`
--

CREATE TABLE `ga_manga_11_pe1_1_2` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ga_manga_11_pe1_1_2`
--

INSERT INTO `ga_manga_11_pe1_1_2` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ga_manga_11_pe1_1_200`
--

CREATE TABLE `ga_manga_11_pe1_1_200` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ga_manga_11_pe1_1_200`
--

INSERT INTO `ga_manga_11_pe1_1_200` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL),
(2, 200, 'sung jin woo', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 201, 'cha hae in', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ga_manga_11_pe1_2_202`
--

CREATE TABLE `ga_manga_11_pe1_2_202` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ga_manga_11_pe1_2_202`
--

INSERT INTO `ga_manga_11_pe1_2_202` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL),
(2, 200, 'sung jin woo', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL),
(4, 201, 'cha hae in', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL),
(5, 203, 'dddd dddd ddd', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 12, NULL, NULL),
(6, 204, 'eee eee eee', 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL),
(7, 205, 'fff fff fff', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL),
(8, 206, 'gggg gggg ggg', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL),
(9, 207, 'hhh hhh hhh', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ga_manga_11_pe1_4_202`
--

CREATE TABLE `ga_manga_11_pe1_4_202` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ga_manga_11_pe1_4_202`
--

INSERT INTO `ga_manga_11_pe1_4_202` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL),
(2, 200, 'sung jin woo', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ga_manga_12_pe1_1_200`
--

CREATE TABLE `ga_manga_12_pe1_1_200` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ga_manga_12_pe1_1_200`
--

INSERT INTO `ga_manga_12_pe1_1_200` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `humms_manga_11_pe1_1_1`
--

CREATE TABLE `humms_manga_11_pe1_1_1` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `humms_manga_11_pe1_1_1`
--

INSERT INTO `humms_manga_11_pe1_1_1` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `name`, `grade`) VALUES
(1, 'Manga', '11'),
(2, 'Bayabas', '11'),
(3, 'Catleya', '11');

-- --------------------------------------------------------

--
-- Table structure for table `stem_manga_11_pe1_1_2`
--

CREATE TABLE `stem_manga_11_pe1_1_2` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stem_manga_11_pe1_1_2`
--

INSERT INTO `stem_manga_11_pe1_1_2` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stem_manga_11_pe1_1_202`
--

CREATE TABLE `stem_manga_11_pe1_1_202` (
  `id` int(6) NOT NULL,
  `stNo` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ww1` int(3) DEFAULT NULL,
  `ww2` int(3) DEFAULT NULL,
  `ww3` int(3) DEFAULT NULL,
  `ww4` int(3) DEFAULT NULL,
  `ww5` int(3) DEFAULT NULL,
  `ww6` int(3) DEFAULT NULL,
  `ww7` int(3) DEFAULT NULL,
  `ww8` int(3) DEFAULT NULL,
  `ww9` int(3) DEFAULT NULL,
  `ww10` int(3) DEFAULT NULL,
  `pt1` int(3) DEFAULT NULL,
  `pt2` int(3) DEFAULT NULL,
  `pt3` int(3) DEFAULT NULL,
  `pt4` int(3) DEFAULT NULL,
  `pt5` int(3) DEFAULT NULL,
  `pt6` int(3) DEFAULT NULL,
  `pt7` int(3) DEFAULT NULL,
  `pt8` int(3) DEFAULT NULL,
  `pt9` int(3) DEFAULT NULL,
  `pt10` int(3) DEFAULT NULL,
  `qa1` int(3) DEFAULT NULL,
  `ig` decimal(3,2) DEFAULT NULL,
  `qg` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stem_manga_11_pe1_1_202`
--

INSERT INTO `stem_manga_11_pe1_1_202` (`id`, `stNo`, `name`, `ww1`, `ww2`, `ww3`, `ww4`, `ww5`, `ww6`, `ww7`, `ww8`, `ww9`, `ww10`, `pt1`, `pt2`, `pt3`, `pt4`, `pt5`, `pt6`, `pt7`, `pt8`, `pt9`, `pt10`, `qa1`, `ig`, `qg`) VALUES
(1, 0, 'HS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 200, 'sung jin woo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `studentlist`
--

CREATE TABLE `studentlist` (
  `id` int(6) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `bday` date NOT NULL,
  `address` varchar(200) NOT NULL,
  `parentContact` varchar(20) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `studentlist`
--

INSERT INTO `studentlist` (`id`, `fname`, `mname`, `lname`, `bday`, `address`, `parentContact`, `photo`) VALUES
(200, 'sung', 'jin', 'woo', '2023-05-18', 'Novalichesss             ', '09381256399', 'images/10092023065921Calamity_Reaper-e1622949727366.png'),
(201, 'asd', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(202, 'sungasd', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(203, 'sungddad', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(204, 'sungfhf', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(205, 'sungjej', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(206, 'sungvcbcv', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(207, 'ngdn', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(208, 'sungterut', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(209, 'jytrjl', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(210, 'wer', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(211, 'sungywg', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(212, 'sunghhww', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(213, 'wwwe', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(214, 'llkl', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(215, 'klk', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(216, 'ioi', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(217, 'pop', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(218, 'sungpup', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(219, 'sungpup', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(220, 'sunguu', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(221, 'uu', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(222, 'oiu', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(223, 'popp', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(224, 'supiing', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(225, 'sung', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]'),
(226, 'sung', 'jin', 'woo', '2023-05-18', 'Novaliches  ', '09381256398', '[value-8]');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `reviewer` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `code`, `reviewer`) VALUES
(101, 'Gymnastic', 'PE2', 'https://www.google.com/');

-- --------------------------------------------------------

--
-- Table structure for table `teachersinfo`
--

CREATE TABLE `teachersinfo` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fName` varchar(100) NOT NULL,
  `mName` varchar(100) NOT NULL,
  `lName` varchar(100) NOT NULL,
  `address` varchar(120) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `birthday` date NOT NULL,
  `age` int(3) NOT NULL,
  `advisory` varchar(80) NOT NULL,
  `civilStatus` varchar(20) NOT NULL,
  `Nationality` varchar(20) NOT NULL,
  `Religion` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `photo` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachersinfo`
--

INSERT INTO `teachersinfo` (`id`, `username`, `password`, `fName`, `mName`, `lName`, `address`, `gender`, `birthday`, `age`, `advisory`, `civilStatus`, `Nationality`, `Religion`, `Email`, `contact`, `photo`) VALUES
(1, '124214124124', '', '3123', '213213', '213213', '123123123', 'Female', '2023-05-19', 0, 'Married', 'Widowed', 'Filipino', 'Muslim', '124214124124@gmail.com', '3pcs 325mns', 'uploads/1684720096.png'),
(2, '123213', '123213', '213123', '3213', '12321312', '21312', 'Male', '2010-06-17', 12, '123213', 'Single', 'Filipino', 'Christian', '312312@gmail.com', '123213', 'papathumb12msn.png'),
(3, '131313134', 'a2132131', 'fname', 'middle', ' lname ', 'qewqe adress', 'Male', '2019-02-20', 4, 'wqeeqwe', 'Single', 'Filipino', 'Catholic', 'ewqewqe@gmail.com', '13131313', 'uploads/1684722115.png'),
(5, 'qweweqewqwe', '1', '213123', 'eewqeqwe', 'weqeeqewq', 'weewqewqewq', 'Male', '2023-05-01', 0, '', 'Single', 'Chinese', 'Muslim', 'wqewqeqwe@gmail.com', '123213', 'uploads/1684719896.png'),
(200, 'ad', '222', 'chris', 'aaaaa', 'a', 'aaaaaaa', 'Female', '2020-07-16', 2, 'asdadsad', 'Single', 'Chinese', 'Catholic', 'sadasdasd@gmail.com', '12321321312', 'uploads/1684719925.png'),
(202, '32132131', '3213213', '2323', '23213', '21321', '32132132', 'Female', '2023-06-13', 0, '23123', 'Married', 'Chinese', 'Muslim', '2321@gmail.com', '32132130', 'uploads/Tape-Measure-PNG-Pic.png'),
(203, 'rrrrr', 'rrrrr', 'rrr', 'rrr', 'rrr', 'rrrrrr', 'Female', '2023-06-21', 0, 'rrrrrr', 'Single', 'Chinese', 'Catholic', 'rwrqr@gmail.com', 'rrrrr', 'uploads/Tambol,, paano patibayinThumb.png'),
(204, 'aaa', 'aaa', 'qwqewq', 'wqeqwe', 'qwe', 'qeqwewq', 'Male', '2023-06-27', 0, 'qweqwe', 'Single', 'Chinese', 'Catholic', 'qweqwewq@Gmail.com', '090999', 'uploads/Untitled-2.png'),
(205, '2323', '2323', 'errrr', 'rr', 'rrrr', 'rrrrrr', 'Male', '2023-06-20', 0, 'rrrrrr', 'Married', 'nationality', 'Catholic', 'rrr@gmail.com', '2323', 'uploads/2b2PIC2HD.png'),
(206, '23232', '1111', 'aa', 'aa', 'aaa', 'aa', 'Female', '0000-00-00', 0, 'dasdad', 'Widowed', 'Chinese', 'Muslim', 'aaa@gmai.com', '2323', 'uploads/647820ff6252dTape-Measure-PNG-Pic.png'),
(207, '', '', '223', '232', '323', '3232', 'Male', '2023-05-31', 0, '232323', 'Single', 'nationality', 'Catholic', '232323@gmail.com', '', 'uploads/647beef642dcc346115857_853533969514297_4909059059395847009_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `sNo` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `fname`, `mname`, `lname`, `sNo`, `user_type`) VALUES
(1, 'admin', 'admin', '', '', '', '', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abm_manga_11_pe1_1_5`
--
ALTER TABLE `abm_manga_11_pe1_1_5`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `abm_manga_11_pe1_1_205`
--
ALTER TABLE `abm_manga_11_pe1_1_205`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `ga_manga_11_pe1_1_2`
--
ALTER TABLE `ga_manga_11_pe1_1_2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `ga_manga_11_pe1_1_200`
--
ALTER TABLE `ga_manga_11_pe1_1_200`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `ga_manga_11_pe1_2_202`
--
ALTER TABLE `ga_manga_11_pe1_2_202`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `ga_manga_11_pe1_4_202`
--
ALTER TABLE `ga_manga_11_pe1_4_202`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `ga_manga_12_pe1_1_200`
--
ALTER TABLE `ga_manga_12_pe1_1_200`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `humms_manga_11_pe1_1_1`
--
ALTER TABLE `humms_manga_11_pe1_1_1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stem_manga_11_pe1_1_2`
--
ALTER TABLE `stem_manga_11_pe1_1_2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `stem_manga_11_pe1_1_202`
--
ALTER TABLE `stem_manga_11_pe1_1_202`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stNo` (`stNo`);

--
-- Indexes for table `studentlist`
--
ALTER TABLE `studentlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachersinfo`
--
ALTER TABLE `teachersinfo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abm_manga_11_pe1_1_5`
--
ALTER TABLE `abm_manga_11_pe1_1_5`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `abm_manga_11_pe1_1_205`
--
ALTER TABLE `abm_manga_11_pe1_1_205`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ga_manga_11_pe1_1_2`
--
ALTER TABLE `ga_manga_11_pe1_1_2`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ga_manga_11_pe1_1_200`
--
ALTER TABLE `ga_manga_11_pe1_1_200`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ga_manga_11_pe1_2_202`
--
ALTER TABLE `ga_manga_11_pe1_2_202`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ga_manga_11_pe1_4_202`
--
ALTER TABLE `ga_manga_11_pe1_4_202`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ga_manga_12_pe1_1_200`
--
ALTER TABLE `ga_manga_12_pe1_1_200`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `humms_manga_11_pe1_1_1`
--
ALTER TABLE `humms_manga_11_pe1_1_1`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stem_manga_11_pe1_1_2`
--
ALTER TABLE `stem_manga_11_pe1_1_2`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stem_manga_11_pe1_1_202`
--
ALTER TABLE `stem_manga_11_pe1_1_202`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `studentlist`
--
ALTER TABLE `studentlist`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `teachersinfo`
--
ALTER TABLE `teachersinfo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
